using System;
public class DisplaySomeMoney
{
   public static void Main()
   {
      double someMoney = 39.45;
      Console.WriteLine(someMoney);
   }
}
