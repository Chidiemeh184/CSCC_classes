using System;
public class CodeForFigure0209
{
   public static void Main()
   {
      int num1 = 4, num2 = 56, num3 = 789;
      Console.WriteLine("{0, 5}", num1);
      Console.WriteLine("{0, 5}", num2);
      Console.WriteLine("{0, 5}", num3);
   }
}
