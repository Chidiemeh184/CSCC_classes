using System;
public class CodeForFigure0207
{
   public static void Main()
   {
      double someMoney = 439.75;
      Console.WriteLine("I have ${0}. ${0}!! ${0}!!",
            someMoney);
   }
}
