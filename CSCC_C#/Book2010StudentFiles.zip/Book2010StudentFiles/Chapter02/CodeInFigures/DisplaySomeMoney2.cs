using System;
public class DisplaySomeMoney2
{
   public static void Main()
   {
      double someMoney = 39.45;
      Console.Write("The money is $");
      Console.WriteLine(someMoney);
   }
}
