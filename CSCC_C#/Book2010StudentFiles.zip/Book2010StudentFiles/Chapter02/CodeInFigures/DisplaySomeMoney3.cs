using System;
public class DisplaySomeMoney3
{
   public static void Main()
   {
      double someMoney = 39.45;
      Console.WriteLine("The money is ${0} exactly",
         someMoney);
   }
}
