// This program greets the user
and multiplies two entered values
public class DebugTwo2
    string name;
    string firstString, secondString;
    int first, second, product;
    Console.WRiteLine("Enter your name");
    name = Console.ReadLine();
    Console.WriteLIne("Hello {0}! Enter an integer", name);
    firstString = Console.ReaDLine();
    first = firstString;
    Console.WriteLine("Enter another integer");
    secondString = ConsoleReadLine;
    second = secondString;
    product = first X second;
    Console.WriteLine("Thank you {1}. The product of {2} and {3} is {4}",
	name, first, second, product);


