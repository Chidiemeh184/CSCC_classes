using System;
public class HelloClass
{
   public static void Main()
   {
      ShowWelcomeMessage();
      Console.WriteLine("Hello");
   }
   public static void ShowWelcomeMessage()
   {
      Console.WriteLine("Welcome");
      Console.WriteLine("It's a pleasure to serve you");
      Console.WriteLine("Enjoy the program");
   }
}
