// Filename DebugOne1.cs
// This program outputs a nursery rhyme
public clas DebugOne1
{
   public static void main()
   {
      System.Console.WriteLine("Mary had a litle lamb")
      System.Console.WriteLine("Its fleece was white as snow");
      System.Console.WriteLine("And everywhere that Mary went);
      System.Console.WriteLine"The lamb was sure to go");
   }
}
