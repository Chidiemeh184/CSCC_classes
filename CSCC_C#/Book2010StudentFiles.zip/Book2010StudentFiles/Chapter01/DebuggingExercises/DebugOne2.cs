// Filename DebugOne2.cs
// This program outputs a large C#
public class DebugOne2
{
   public void Main
   {
      System.WriteLine("CCCCC   #  #");
      System.WriteLine("C     ########");
      System.WriteLine("C       #  #");
      Sysetm.WriteLine("C     #########");
      System.WriteLine("CCCCC   #  #");
   }
}
