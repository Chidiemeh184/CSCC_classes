// Filename DebugOne4.cs  
// This program outputs a recipe

public clas DebugOne4
   public static void maine[]
   {
      Console.WriteLine("Spinach dip:");
      Console.WriteLine();
      Console.WriteLine("1 package frozen chopped spinach");
      Console.WriteLine("1 cup mayonaise");
      Console.WriteLine("1 chopped onion");
      Console.WriteLine();
      Console.WriteLine("Mix ingredients together.");
      Console.WriteLine("Chill and serve with chips.");
   }

