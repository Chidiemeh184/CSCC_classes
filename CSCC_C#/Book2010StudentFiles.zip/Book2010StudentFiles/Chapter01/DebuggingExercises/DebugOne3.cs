// Filename DebugOne3.cs
// This program outputs directions to a party
using Sysstem
public class DebugOne3
{
   public static Main()
   {
      Console.WriteLine("Take Highway 51 north");
      Console.WriteLine("Exit at County Road H");
      Console.WriteLiie("Go three blocks and make a right on  School Street");
      Console.WriteLnne("Go right at Elm");
      Console.Writeline("Party is four houses down on the left");
   }
}
