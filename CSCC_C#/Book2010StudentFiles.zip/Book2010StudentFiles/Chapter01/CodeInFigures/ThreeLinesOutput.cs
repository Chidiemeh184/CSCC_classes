using System;
public class ThreeLinesOutput
{
   public static void Main()
   {
      Console.WriteLine("Line one");
      Console.WriteLine("Line two");
      Console.WriteLine("Line three");
   }
}

