public class AnyLegalClassName
{
   public static void Main()
   {
      /*********/;
   }
}
