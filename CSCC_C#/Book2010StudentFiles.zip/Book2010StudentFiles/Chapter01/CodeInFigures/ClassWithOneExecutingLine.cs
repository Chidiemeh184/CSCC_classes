/* This program is written to demonstrate
   using comments */
public class ClassWithOneExecutingLine
{
   public static void Main()
   {
      // The next line writes the message
      System.Console.WriteLine("Message");
   }  // End of Main
} // End of class