public class FirstClass
{
   public static void Main()
   {
      System.Console.WriteLine("This is my first C# program");
   }
}
