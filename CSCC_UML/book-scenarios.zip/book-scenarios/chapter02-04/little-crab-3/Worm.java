import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * Worm. A sand worm. Very yummy. Especially crabs really like it.
 */
public class Worm extends Actor
{

}
