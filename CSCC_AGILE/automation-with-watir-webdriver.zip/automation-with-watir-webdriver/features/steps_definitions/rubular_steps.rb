require 'watir-webdriver'

#				 Scenario: Testing an email address
Given(/Given I at the rubular homepage$/)do
	@browser.goto 'http://www.rubular.com'
end

When(/^I enter a regular expression for a full email address$/) do
	@browser.text_field(:id => 'regex').flash
	@browser.text_field(:id => 'regex').set "(.*)@(.*)\.(.*)"
end

Then(/^I shoud be able to test an email address "jdenen@cscc.edu"$/) do
	@browser.textarea(:id => 'test').set "jdenen@cscc.edu"
	result = @browser.element(:id => 'error').present?
	expect(@result).to be_false
end


#		           Scenario: Returning a match result
When(/^I test the string "jdenen@cscc.edu"$/) do
	@browser.textarea(:id => 'test').set "jdenen@cscc.edu"
end

Then(/^I get a match result of "jdenen@cscc.edu"$/) do
	match_result = @browser.div(:id => 'match_string').text
	text_string = @browser.div(:id => 'inner_test_string_wrapper').text
	expect(text_string).to eq(match_result)
end


#				 Scenario: Returning a match group
Then(/^I get three match groups; "jdenen", "cscc", "edu"$/) do
	first_text = 'jdenen'
	second_text = 'cscc'
	third_text = 'edu'
	table_value = @browser.div(:id => 'match_captures').text
	
	expect(table_value).to include first_text, second_text, third_text
end


#			Scenario: Match group formatted in new line
When(/^I test a string$/) do
	@browser.textarea(:id => 'test').set "jdenen@cscc.edu"
end

Then(/^the match group is formatted in nem line$/) do
	table_value = @browser.div(:id => 'match_captures').text.include? "\n"
	expect(table_value).to be_true
end


#			Scenario: Match group preceded by an index number  
When(/^I test string of email address$/) do
	@browser.textarea(:id => 'test').set "jdenen@cscc.edu"
end

Then(/^the match group is preceded by an index number$/) do
	first_index_number = '1.'
	second_index_number = '2.'
	third_index_number = '3.'
  
	expect(table_value).to include first_index_number
	expect(table_value).to include second_index_number
	expect(table_value).to include third_index_number
end






